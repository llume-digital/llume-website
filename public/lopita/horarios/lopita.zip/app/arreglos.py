"""Horarios que valen: generar con reintentos y arreglar los que una ausencia ha dejado sin gente.

Orquesta el dominio (generacion.asegurar) con la base de datos y deja una notificación al encargado cuando
algo necesita su atención: una generación que sigue con alertas críticas tras los reintentos, o un arreglo
preparado tras una ausencia. Nunca publica: un horario publicado solo cambia cuando el encargado publica el
arreglo (un borrador que lo sustituye); hasta entonces el equipo sigue viendo el que había.
"""
from __future__ import annotations

import datetime as dt
from typing import Optional

from lopita_horarios.criticas import Problema
from lopita_horarios.generacion import Resultado, asegurar
from lopita_horarios.models import Config, Lock, Schedule
from lopita_horarios.solucionador import congelar_antes
from lopita_horarios.solver import SolveOptions

from . import horas
from .db import Store

_DIAS = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]


def periodo(h: Schedule) -> str:
    return f"del {h.desde.day:02d}/{h.desde.month:02d} al {h.hasta.day:02d}/{h.hasta.month:02d}"


def primer_dia_cambiable(estado: str, h: Schedule, hoy: dt.date) -> dt.date:
    """Lo ya pasado no se toca; en un horario publicado tampoco el día de hoy, que ya está en marcha."""
    return max(h.desde, hoy + dt.timedelta(days=1) if estado == "publicado" else hoy)


def _texto(p: Problema) -> str:
    return p.texto + (f" {p.causa}" if p.causa else "")


def informe(res: Resultado) -> dict:
    """Lo que la interfaz necesita para contar qué ha pasado al generar o arreglar."""
    return {"valido": res.valido, "motivo": res.motivo,
            "intentos": [i.model_dump(mode="json") for i in res.intentos],
            "reintentos": sum(1 for i in res.intentos if i.metodo != "generar"),
            "problemas": [_texto(p) for p in res.problemas]}


def generar(store: Store, config: Config, desde: dt.date, hasta: dt.date, *, segundos: float,
            excluir: Optional[int] = None, bloqueos: Optional[list[Lock]] = None,
            congelados: Optional[list[Lock]] = None, partir_de: Optional[Schedule] = None,
            cambiable_desde: Optional[dt.date] = None) -> Resultado:
    """Genera (o arregla 'partir_de') con el contexto de la base de datos: periodo anterior y saldo de horas."""
    previo = store.assignments_before(desde, exclude=excluir)
    saldo = horas.saldo_arrastrado(config, store.previous_contiguous(desde, exclude=excluir),
                                   store.list_requests(tipo="correccion", estado="aprobada"))
    return asegurar(config, partir_de, desde=desde, hasta=hasta, opciones=SolveOptions(max_segundos=segundos),
                    previo=previo, bloqueos=bloqueos, saldo_horas=saldo, congelados=congelados,
                    cambiable_desde=cambiable_desde)


def _lista_problemas(res: Resultado) -> str:
    n = len(res.problemas)
    return f"{n} alerta{'s' if n != 1 else ''} crítica{'s' if n != 1 else ''}"


def notificar_generacion(store: Store, sid: int, res: Resultado, regenerado: bool = False) -> None:
    """Solo si, tras los reintentos, el horario sigue sin valer."""
    if res.valido:
        return
    h = res.horario
    reintentos = sum(1 for i in res.intentos if i.metodo != "generar")
    texto = (f"Ha quedado con {_lista_problemas(res)}"
             + (f" después de {reintentos} reintento{'s' if reintentos != 1 else ''}" if reintentos else "")
             + f". {res.motivo or 'Es posible que haya que cambiar algo para arreglarlo.'} "
               "No lo publiques sin revisarlo: si lo publicas, la app te pedirá confirmarlo.")
    store.create_notification(
        "generacion_fallida", sid,
        f"El horario {periodo(h)} no se ha {'regenerado' if regenerado else 'generado'} correctamente",
        " ".join(texto.split()), informe(res))


def _turnos_imposibles(config: Config, h: Schedule, desde: dt.date) -> bool:
    """Si hay turnos que ya no se van a hacer: la persona está ausente o ya no está en la plantilla."""
    activos = {e.id for e in config.active_employees()}
    return any(a.fecha >= desde and (a.empleado_id not in activos or config.is_absent(a.empleado_id, a.fecha))
               for a in h.asignaciones)


def arreglar_tras_ausencias(store: Store, config: Config, hoy: dt.date, segundos: float) -> list[int]:
    """Arregla los horarios en curso o futuros con turnos que ya no se van a hacer (ausencias, bajas en la plantilla).

    Un borrador se arregla tal cual. Un horario publicado no se toca: el arreglo se guarda como un borrador que
    lo sustituye cuando el encargado lo publique. Devuelve los ids de los borradores creados o arreglados.
    """
    filas = store.list_schedules()
    publicados = {r["id"] for r in filas if r["estado"] == "publicado"}
    hechos = []
    for row in filas:
        h: Schedule = row["horario"]
        if h.hasta < hoy or (row["estado"] != "publicado" and row.get("reemplaza") in publicados):
            continue  # ya terminado, o arreglo pendiente de un publicado (se trata junto a él)
        publicado = row["estado"] == "publicado"
        pendiente = store.replacement_of(row["id"]) if publicado else None
        base_row = pendiente or row
        base: Schedule = base_row["horario"]
        desde = primer_dia_cambiable("publicado" if publicado else "borrador", base, hoy)
        if desde > base.hasta or not _turnos_imposibles(config, base, desde):
            continue
        res = generar(store, config, base.desde, base.hasta, segundos=segundos, excluir=row["id"],
                      bloqueos=base.bloqueos, partir_de=base, cambiable_desde=desde,
                      congelados=congelar_antes(config, base, desde) if desde > base.desde else [])
        nuevo = res.horario
        nuevo.estado = "borrador"
        if pendiente:
            store.update_schedule(pendiente["id"], nuevo)
            sid = pendiente["id"]
        elif publicado:
            sid = store.create_schedule(nuevo, "sistema", reemplaza=row["id"])
        else:
            store.update_schedule(row["id"], nuevo)
            sid = row["id"]
        hechos.append(sid)
        _notificar_arreglo(store, sid, res, publicado)
    return hechos


def _notificar_arreglo(store: Store, sid: int, res: Resultado, publicado: bool) -> None:
    h = res.horario
    if publicado:
        titulo = f"Arreglo preparado para el horario publicado {periodo(h)}"
        texto = ("Una ausencia ha dejado turnos que nadie va a hacer. He preparado el arreglo como borrador: revísalo y "
                 "publícalo. Hasta entonces el equipo sigue viendo el horario actual.")
    else:
        titulo = f"Borrador {periodo(h)} arreglado"
        texto = "Una ausencia había dejado turnos que nadie iba a hacer en este borrador y lo he ajustado."
    if not res.valido:
        titulo = (f"Arreglo incompleto del horario publicado {periodo(h)}" if publicado
                  else f"El borrador {periodo(h)} sigue sin valer")
        texto += f" Aun así queda{'n' if len(res.problemas) != 1 else ''} {_lista_problemas(res)}. {res.motivo or ''}"
    store.create_notification("arreglo_preparado" if publicado else "arreglo_borrador", sid, titulo,
                              " ".join(texto.split()), informe(res))

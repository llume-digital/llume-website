"""Informe de horas por trabajador: horas previstas (horario publicado) y ajustadas (correcciones aprobadas)."""
from __future__ import annotations

import datetime as dt
from typing import Optional

from lopita_horarios.models import Config, Schedule, parse_hhmm

CLASES = {
    "horas": "Horas distintas",
    "turno": "Turno distinto",
    "no_trabajado": "No trabajé",
    "extra": "Día extra",
}


def correction_minutes(config: Config, datos: dict) -> int:
    """Minutos realmente trabajados según una corrección."""
    clase = datos.get("clase")
    if clase == "no_trabajado":
        return 0
    if clase == "turno" or (clase == "extra" and datos.get("turno_id")):
        return config.shift(datos["turno_id"]).minutes
    ini, fin = parse_hhmm(datos["inicio"]), parse_hhmm(datos["fin"])
    if fin <= ini:
        raise ValueError("La hora de salida debe ser posterior a la de entrada")
    return fin - ini


def validate_correction(config: Config, datos: dict) -> dict:
    """Normaliza y valida los datos de una corrección. Lanza ValueError con un mensaje claro."""
    clase = datos.get("clase")
    if clase not in CLASES:
        raise ValueError("Tipo de corrección desconocido")
    out = {"clase": clase, "fecha": str(datos.get("fecha") or "")}
    try:
        dt.date.fromisoformat(out["fecha"])
    except ValueError:
        raise ValueError("Indica la fecha")
    if clase == "turno" or (clase == "extra" and datos.get("turno_id")):
        tid = datos.get("turno_id")
        if not tid or tid not in {s.id for s in config.turnos}:
            raise ValueError("Elige el turno que hiciste")
        out["turno_id"] = tid
    elif clase in ("horas", "extra"):
        for k in ("inicio", "fin"):
            try:
                parse_hhmm(str(datos.get(k)))
            except Exception:
                raise ValueError("Indica la hora de entrada y la de salida")
            out[k] = str(datos[k])
    out["minutos"] = correction_minutes(config, out)
    if out["minutos"] > 16 * 60:
        raise ValueError("Una jornada no puede superar las 16 horas")
    return out


def best_schedules(rows: list[dict], solo_publicados: bool = True) -> dict[dt.date, Schedule]:
    """Para cada fecha, el horario más fiable que la cubre (publicado antes que borrador, el más reciente)."""
    best: dict[dt.date, tuple] = {}
    for s in rows:
        if solo_publicados and s["estado"] != "publicado":
            continue
        h: Schedule = s["horario"]
        rank = (s["estado"] == "publicado", s["updated_at"])
        d = h.desde
        while d <= h.hasta:
            if d not in best or rank > best[d][0]:
                best[d] = (rank, h)
            d += dt.timedelta(days=1)
    return {d: h for d, (_, h) in best.items()}


def planned_minutes(config: Config, h: Schedule, emp_id: str, fecha: dt.date) -> tuple[Optional[str], int]:
    a = next((x for x in h.asignaciones if x.empleado_id == emp_id and x.fecha == fecha), None)
    if not a:
        return None, 0
    return a.turno_id, config.turno_de(a).minutes


def approved_by_day(requests: list[dict]) -> dict[tuple[str, str], dict]:
    """Última corrección aprobada de cada (empleado, fecha)."""
    out: dict[tuple[str, str], dict] = {}
    for r in sorted((r for r in requests if r["tipo"] == "correccion" and r["estado"] == "aprobada"), key=lambda r: r["id"]):
        out[(r["empleado_id"], r["datos"]["fecha"])] = r
    return out


def employee_report(config: Config, schedules: list[dict], requests: list[dict], emp_id: str,
                    desde: dt.date, hasta: dt.date) -> dict:
    cover = best_schedules(schedules)
    approved = approved_by_day(requests)
    pendientes = sum(1 for r in requests if r["tipo"] == "correccion" and r["estado"] == "pendiente"
                     and r["empleado_id"] == emp_id and desde.isoformat() <= r["datos"]["fecha"] <= hasta.isoformat())
    dias, prev_min, adj_min = [], 0, 0
    d = desde
    while d <= hasta:
        h = cover.get(d)
        if h is not None:
            tid, pm = planned_minutes(config, h, emp_id, d)
            corr = approved.get((emp_id, d.isoformat()))
            am = corr["datos"]["minutos"] if corr else pm
            if tid or corr:
                dias.append({"fecha": d.isoformat(), "turno_id": tid, "previstas": round(pm / 60, 2),
                             "ajustadas": round(am / 60, 2),
                             "correccion": ({"id": corr["id"], "clase": corr["datos"]["clase"], "motivo": corr["motivo"],
                                             "turno_id": corr["datos"].get("turno_id"),
                                             "inicio": corr["datos"].get("inicio"), "fin": corr["datos"].get("fin")}
                                            if corr else None)})
            prev_min += pm
            adj_min += am
        d += dt.timedelta(days=1)
    return {"empleado_id": emp_id, "nombre": config.employee(emp_id).nombre, "desde": desde.isoformat(),
            "hasta": hasta.isoformat(), "previstas": round(prev_min / 60, 2), "ajustadas": round(adj_min / 60, 2),
            "diferencia": round((adj_min - prev_min) / 60, 2), "pendientes": pendientes, "dias": dias}


def saldo_delta(config: Config, h: Schedule, requests: list[dict]) -> dict[str, float]:
    """Horas (+/-) que las correcciones aprobadas añaden al saldo de cada empleado dentro de un horario."""
    out: dict[str, float] = {}
    for (emp, fecha), r in approved_by_day(requests).items():
        f = dt.date.fromisoformat(fecha)
        if not h.desde <= f <= h.hasta:
            continue
        try:
            _, pm = planned_minutes(config, h, emp, f)
        except StopIteration:
            continue
        out[emp] = out.get(emp, 0) + (r["datos"]["minutos"] - pm) / 60
    return {k: round(v, 2) for k, v in out.items()}


def saldo_arrastrado(config: Config, prev: Optional[Schedule], aprobadas: list[dict]) -> dict[str, float]:
    """Saldo de horas (+/-) que cada persona arrastra del horario anterior al siguiente, acotado al máximo configurado."""
    if not config.reglas.arrastrar_saldo or prev is None:
        return {}
    cap = config.reglas.max_saldo_horas
    ajustes = saldo_delta(config, prev, aprobadas)
    saldo = {}
    for st in prev.resumen:
        total = st.horas - st.horas_objetivo + ajustes.get(st.empleado_id, 0)
        if abs(total) >= 0.5:
            saldo[st.empleado_id] = max(-cap, min(cap, round(total, 2)))
    return saldo
